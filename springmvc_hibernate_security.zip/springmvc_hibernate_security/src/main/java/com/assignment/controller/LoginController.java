package com.assignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.assignment.dao.EmpDAO;
import com.assignment.model.Employee;
import com.assignment.model.Login;

@Controller
public class LoginController {

  @Autowired
  EmpDAO empDAO;

//  @RequestMapping(value = "/login", method = RequestMethod.GET)
//  public ModelAndView showLogin() {
//    ModelAndView mav = new ModelAndView("login");
//    mav.addObject("login", new Login());
//
//    return mav;
//  }
  
  @RequestMapping(value = "/admin", method = RequestMethod.GET)
	public ModelAndView adminPage() {

		ModelAndView model = new ModelAndView();
		model.addObject("list",empDAO.getEmployees());
		model.setViewName("viewemp");
		return model;
	}
  
  @RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam(value = "error", required = false) String error) {

		ModelAndView model = new ModelAndView();
		if (error != null) {
			model.addObject("error", "Invalid username and password!");
		}

		model.setViewName("login");

		return model;

	}
	@RequestMapping(value="/logout")
	public ModelAndView logout()
	{
		ModelAndView m=new ModelAndView();
		m.setViewName("logout");
		return m;
		
	}

  @RequestMapping(value = "/myDetails")
  public ModelAndView loginProcess(@ModelAttribute("login") Login login) {
    ModelAndView mav = null;

    Employee e = empDAO.validateEmployee(login);

    if (null != e) {
      mav = new ModelAndView("mydetails");
      mav.addObject("emp", e);
    } else {
      mav = new ModelAndView("login");
      mav.addObject("message", "Username or Password is wrong!!");
    }

    return mav;
  }
  

}