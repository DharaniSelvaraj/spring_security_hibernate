package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.assignment.model.Employee;
import com.assignment.model.Login;
import com.assignment.dao.EmpDAO;

@Controller
public class EmpController {
	
	@Autowired
	EmpDAO empDAO;
	
	@RequestMapping("/empform")
	public String showEmpForm(Model m)
	{
		m.addAttribute("emp", new Employee());
		return "empform";
	}
	
	@RequestMapping(value="/saveemp",method=RequestMethod.POST)
	public String saveEmpDetails(@ModelAttribute("emp") Employee emp)
	{
		System.out.print("printttt");
		empDAO.saveEmployee(emp);
		return "redirect:/viewemp";
	}
	
	@RequestMapping("/viewemp")    
    public String viewemp(Model m){    
        List<Employee> list=empDAO.getEmployees();    
        m.addAttribute("list",list);  
        return "viewemp";    
    }
	@RequestMapping(value="/editemp/{id}")
	public String edit(@PathVariable int id,Model m)
	{
		Employee E=empDAO.getById(id);
		m.addAttribute("emp",E);
		return "empeditform";
	}
	@RequestMapping(value="/saveedit",method=RequestMethod.POST)
	public String editsave(@ModelAttribute("emp") Employee emp)
	{
		
		empDAO.updateEmployee(emp);
		return "redirect:/viewemp";
	}
	@RequestMapping(value="/deleteemp/{id}")
	public String deleteemp(@PathVariable int id)
	{
		Employee e=empDAO.getById(id);
		empDAO.deleteEmployee(e);
		return "redirect:/viewemp";
	}
	
	
}
