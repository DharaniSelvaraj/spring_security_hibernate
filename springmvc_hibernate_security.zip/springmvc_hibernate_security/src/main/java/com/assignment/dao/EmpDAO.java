package com.assignment.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.assignment.model.Employee;
import com.assignment.model.Login;

public class EmpDAO {
		HibernateTemplate template;  
		public void setTemplate(HibernateTemplate template) {  
		    this.template = template;  
		}  
		//method to save employee  
		public void saveEmployee(Employee e){  
		    template.save(e);  
		}  
		//method to update employee  
		public void updateEmployee(Employee e){  
		    template.update(e);  
		}  
		//method to delete employee  
		public void deleteEmployee(Employee e){  
		    template.delete(e);  
		}  
		//method to return one employee of given id  
		public Employee getById(int id){  
		    Employee e=(Employee)template.get(Employee.class,id);  
		    return e;  
		}  
		//method to return all employees  
		public List<Employee> getEmployees(){  
		    List<Employee> list=new ArrayList<Employee>();  
		    list=template.loadAll(Employee.class);  
		    return list;  
		}
		
		public Employee validateEmployee(Login login) {
			// TODO Auto-generated method stub
			String query="select e from Employee e where name=? and password=?";
	        Object[] queryParam = {login.getUsername(),login.getPassword()};
	        List<Employee> emps = (List<Employee>) template.find(query, queryParam);
	        Employee e=null;
	        if(emps!=null)
	        {
	        	e=emps.get(0);
	        }
	        return e;
		}  
}  

